#include <iostream>
using namespace std;
int main() {
   
   int num;

   cin >> num;
   // cin>>num;

   // if( num % 2 == 0  ){
   // 		cout<<"even"<<endl;
   // }
   // else{
   // 		cout<<"odd"<<endl;
   // }

   if(num < 33){
   	cout<<"fail"<<endl;
   }

   else if(num < 75){
   	cout<<"bas pass"<<endl;
   }
   else{
   	 cout<<"distinction"<<endl;
   }



}











