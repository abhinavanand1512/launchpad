#include <iostream>
using namespace std;
int main() {

	int num;
	cin>>num;

	int i =0;

	while( i <= num){

		if( i%2 !=0){
			cout<<i<<endl;
		}
		i=i+1;
	}

}