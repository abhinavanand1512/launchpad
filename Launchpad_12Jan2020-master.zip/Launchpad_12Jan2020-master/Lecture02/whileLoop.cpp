#include <iostream>
using namespace std;
int main()
{
	int i = 0; //initialization

	while( i <= 10){ //termination
		cout << i << endl;
		i=i+1; // processing
	}

	
	return 0;
}