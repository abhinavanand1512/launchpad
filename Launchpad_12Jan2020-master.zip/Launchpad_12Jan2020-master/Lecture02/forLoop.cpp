#include <iostream>
using namespace std;

int main()
{
	
	// for (int i =0; i < 10; i = i+1 )
	// {
	// 	cout<< 2*i <<endl;
	// }
	int i =0;
	for ( ; i < 10; )
	{
		cout<< 2*i <<endl;
		 i = i+1;
	}


	return 0;
}










