#include <bits/stdc++.h>
using namespace std;
int main(int argc, char const *argv[])
{
	
	// int i = 10;
	// unsigned int j = 15;
	// signed int k = 34;

	// cout<<i<<endl;
	// char ch = 'Z';
	// float f = 8759.79384;
	// cout<<ch<<endl;
	// cout<<(int)ch<<endl;
	// cout<<f<<endl;
	// cout<<(int)f<<endl;
	// if('a' < 'B'){
	// 	cout<<" A < B is true"<<endl;
	// }
	// else{
	// 	cout<<" A < B is false"<<endl;
	// }
	// // cout<<sizeof(i)<<endl;
	// // cout<<sizeof(ch)<<endl;
	// // cout<<sizeof(double)<<endl;
	// // cout<<sizeof(float)<<endl;
	// // cout<<sizeof(bool)<<endl;
	// // cout<<INT_MAX<<endl;
	// // cout<<INT_MIN<<endl;


	// long long int g = 78;
	// long int m = 78;

	// cout<<sizeof(m)<<endl;

	// int i =5;
	// int j = 7;
	// int k = 8;
	// int l = 9;
	// bool a = true;
	// bool b = true;

	// if(i < j || k < l){
	// 	cout<<"a || b is true"<<endl;
	// }
	// else{
	// 	cout<<"a || b is false"<<endl;
	// }
	// if(!(a && b)){
	// 	cout<<"a && b is true"<<endl;
	// }
	// else{
	// 	cout<<"a && b is false"<<endl;
	// }

		// int a = 5 & 7;
		// int b = 5 | 7;
		// int c = ~5;
		// int d = 5 << 2;
		// int e = 10 >> 2;
		// int f = 17 ^ 32;
		// cout<<a<<endl;
		// cout<<b<<endl;
		// cout<<c<<endl;
		// cout<<d<<endl;
		// cout<<e<<endl;
		// cout<<f<<endl;

	int num = INT_MAX;

	num = num + 2;
	cout<<INT_MIN<<endl;
	cout<<num<<endl;

cout<<"----=---------"<<endl;

	int num2 = INT_MIN;
	num2 = num2-2;
	cout<<INT_MAX<<endl;
	cout<<num2<<endl;










	return 0;
}








