#include <bits/stdc++.h>
using namespace std;

int main(int argc, char const *argv[])
{
	// int i = 5;
	// int j = 10;
	// // int b = i++;
	// // int a = ++j;
	// //i = ++i;
	// int b = i--;
	// int a = --j;
	// cout<< i<<" "<< b<<endl;
	// cout<< j<<" "<< a<<endl;
	int n = 1;
	int m = 1;
	int k = ++n;
	int z = n++;
	//cout<< ++n + m++ <<endl;
	cout<< k + z <<endl;

	// cout<<n++<<" "<<m++<<endl;
	// cout<<++n<<" "<<m++<<endl;


	return 0;
}










